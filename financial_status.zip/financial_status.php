<?php
include("admin_header.php");
session_start();
include("../include/connection.php");

$query = "SELECT * FROM financial_statement WHERE status = 'ACTIVE'";
$result = mysqli_query($connection, $query);

?>
<body id="page-top">
    <div id="wrapper">
        <?php
        include("admin_sidebar.php");
        ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php
                include("admin_topbar.php");
                ?>
<?php
// Database connection
$host = 'localhost';
$db = 'somsystem';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add transaction
if (isset($_POST['add_transaction'])) {
    $organization = $_POST['organization'];
    $type = $_POST['type'];
    $amount = $_POST['amount'];

    if ($type === 'income') {
        $sql = "UPDATE financial_status SET income = income + ? WHERE organization_name = ?";
    } else {
        $sql = "UPDATE financial_status SET expenses = expenses + ? WHERE organization_name = ?";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ds', $amount, $organization);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Transaction added successfully!');</script>";
}

// Fetch financial data
$result = $conn->query("SELECT * FROM financial_status");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            text-align: center;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: blue;
            
        }

        button{
            background-color: green;
            color: while;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            cursor:pointer;
            transition: all 0.3s ease;
        }
            

    </style>
</head>
<body>
    <h2>Financial Status</h2>

    <table>
        <thead>
            <tr>
                <th>Organization</th>
                <th>Income (₱)</th>
                <th>Expenses (₱)</th>
                <th>Net Balance (₱)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): 
                $balance = $row['income'] - $row['expenses'];
            ?>
                <tr>
                    <td><?= $row['organization_name'] ?></td>
                    <td><?= number_format($row['income'], 2) ?></td>
                    <td><?= number_format($row['expenses'], 2) ?></td>
                    <td><?= number_format($balance, 2) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Add Transaction</h2>
    <form action="" method="POST">
        <label for="organization">Organization:</label>
        <select name="organization" id="organization" required>
            <?php
            $result = $conn->query("SELECT organization_name FROM financial_status");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['organization_name']}'>{$row['organization_name']}</option>";
            }
            ?>
        </select>
        <label for="type">Type:</label>
        <select name="type" id="type" required>
            <option value="income">Income</option>
            <option value="expenses">Expenses</option>
        </select>
        <label for="amount">Amount (₱):</label>
        <input type="number" name="amount" id="amount" required>
        <button type="submit" name="add_transaction">Add</button>
    </form>
</body>
</html>
