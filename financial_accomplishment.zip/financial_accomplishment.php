<?php
include("admin_header.php");
session_start();
include("../include/connection.php");

$query = "SELECT * FROM financial_statement WHERE status = 'ACTIVE'";
$result = mysqli_query($connection, $query);

?>
<body id="page-top">
    <div id="wrapper">
        <?php
        include("admin_sidebar.php");
        ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php
                include("admin_topbar.php");
                ?>
<?php
// Database connection
$host = 'localhost';
$db = 'somsystem';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add transaction
if (isset($_POST['add_transaction'])) {
    $organization = $_POST['organization'];
    $date = $_POST['date'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $amount = $_POST['amount'];

    $sql = "INSERT INTO financial_accomplishments (organization_name, date, description, type, amount)
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssd', $organization, $date, $description, $type, $amount);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Transaction added successfully!');</script>";
}

// Fetch financial data
$result = $conn->query("SELECT * FROM financial_accomplishments ORDER BY date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Accomplishment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            text-align: center;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f4f4f4;
        }

    
    button {
        background-color: greenyellow;
        color: while;
        border: none;
        padding: 12px 20px;
        font-size: 16px;
        font-weight: bold;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        cursor:pointer;
        transition: all 0.3s ease;
        
    }

    .custom-button:hover{
        background-color: #003f7f;
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
    }


    .custom-button:active{
        background-color: #003f7f;
        transform: scale(0.98);
    }
    
    
    </style>

</head>
<body>
    <h1>Student Organization Management System</h1>
    <h2>Financial Accomplishment</h2>

    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Organization</th>
                <th>Description</th>
                <th>Type</th>
                <th>Amount (₱)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['date'] ?></td>
                    <td><?= $row['organization_name'] ?></td>
                    <td><?= $row['description'] ?></td>
                    <td><?= ucfirst($row['type']) ?></td>
                    <td><?= number_format($row['amount'], 2) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Add Financial Accomplishment</h2>
    <form action="" method="POST">
        <label for="organization">Organization:</label>
        <input type="text" name="organization" id="organization" required>
        <br><br>
        <label for="date">Date:</label>
        <input type="date" name="date" id="date" required>
        <br><br>
        <label for="description">Description:</label>
        <textarea name="description" id="description" rows="4" cols="50" required></textarea>
        <br><br>
        <label for="type">Type:</label>
        <select name="type" id="type" required>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
        </select>
        <br><br>
        <label for="amount">Amount (₱):</label>
        <input type="number" name="amount" id="amount" step="0.01" required>
        <br><br>
        <button type="submit" name="add_transaction">Add Transaction</button>
    </form>
</body>
</html>
